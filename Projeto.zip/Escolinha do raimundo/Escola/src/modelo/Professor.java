package modelo;

public class Professor {
    private int prontuario;
    private String nome;
    private Disciplina disciplina;

    // Getters e Setters                                            // Professor utiliza prontuario e nome  e disciplina entao vamos utilizar que ele faça 
    public int getProntuario() {
        return prontuario;
    }

    public void setProntuario(int prontuario) {
        this.prontuario = prontuario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }
}
