package modelo;

public class Disciplina {
    private int codigo;
    private String nome;
    private Curso curso;
                                                        // FAMOSO GETTERS E SETTERS ESTAMOS MOSTRANDO DA CLASSE DISCIPLINA 
    // Getters e Setters
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }
}


