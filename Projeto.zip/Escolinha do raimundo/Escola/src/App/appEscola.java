package App;

import java.util.*;
import modelo.*;

public class appEscola {

    public static void main(String[] args) {
        ArrayList<Professor> professores = entradaDados();

        for (Professor prof : professores) {
            saidaDados(prof);
        }
    }

    public static ArrayList<Professor> entradaDados() {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Professor> lista = new ArrayList<>();

        while (true) {
            Professor prof = new Professor();
            Disciplina disc = new Disciplina();
            Curso curso = new Curso();

            System.out.println("Digite o prontuário do professor:");
            prof.setProntuario(Integer.parseInt(scanner.nextLine()));

            System.out.println("Digite o nome do professor:");
            prof.setNome(scanner.nextLine());

            System.out.println("Digite o código da disciplina:");
            disc.setCodigo(Integer.parseInt(scanner.nextLine()));

            System.out.println("Digite o nome da disciplina:");
            disc.setNome(scanner.nextLine());

            System.out.println("Digite a sigla do curso:");
            curso.setSigla(scanner.nextLine());

            System.out.println("Digite o nome do curso:");
            curso.setNome(scanner.nextLine());

            disc.setCurso(curso);
            prof.setDisciplina(disc);

            lista.add(prof);

            System.out.println("Deseja cadastrar outro professor? (s/n)");
            String opcao = scanner.nextLine();
            if (opcao.equalsIgnoreCase("n")) {
                break;
            }
        }

        return lista;
    }

    public static void saidaDados(Professor professor) {
        System.out.println("\n=== Dados do Professor ===");
        System.out.println("Prontuário: " + professor.getProntuario());
        System.out.println("Nome: " + professor.getNome());

        Disciplina disc = professor.getDisciplina();
        System.out.println("Disciplina: " + disc.getNome() + " (Código: " + disc.getCodigo() + ")");

        Curso curso = disc.getCurso();
        System.out.println("Curso: " + curso.getNome() + " (Sigla: " + curso.getSigla() + ")");
    }
}


